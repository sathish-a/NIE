package com.kewldevs.sathish.nie.Others;

/**
 * Created by sathish on 3/23/17.
 */

public class Helper {

    public static String TAG = "NIE";
    public static String ADMIN = "admin", PASSWORD = "pass";
    public static String SELECTED_COLOR = "#f44336",CLEAR_COLOR = "#b4ebf2";


}
